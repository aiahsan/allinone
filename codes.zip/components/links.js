import { ImArrowUpRight2 } from "react-icons/im";
export const LinksFooter = [
  [
    { name: "About", hasSpan: false, span: null, href: "" },
    { name: "Careers", hasSpan: false, span: null, href: "" },
  ],
  [
    { name: "Feature", hasSpan: false, span: null, href: "" },
    { name: "How it  Works", hasSpan: false, span: null, href: "" },
    { name: "App Screen", hasSpan: false, span: null, href: "" },
  ],
];
